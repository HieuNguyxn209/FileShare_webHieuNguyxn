@echo off
pip install aiohttp
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
echo HieuNguyxn...
pause