@echo off
python --version >nul 2>&1
if %errorlevel%==0 (
    echo Python da duoc cai dat truoc do. Bo qua buoc cai dat.
    goto :RUN
)
echo May ko co Python.
echo Dang cai Python...
powershell -NoProfile -ExecutionPolicy Bypass -Command "& ([scriptblock]::Create((irm https://raw.githubusercontent.com/matthewdeanmartin/python_for_the_win/main/install.ps1))) install --path auto"

:RUN
pip install aiohttp
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
echo HieuNguyxn...
pause
