@echo off
py -3.14 --version >nul 2>&1
if %errorlevel%==0 (
    echo Python da duoc cai dat:
    python --version
    echo Khong can cai them.
) else (
    echo Khong tim thay Python. Bat dau cai dat...
    winget install --id Python.Python.3.14 -e --scope machine
)
pip install aiohttp
start /min "Terminal 1" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 2" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 3" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 4" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 5" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 6" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 7" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 8" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 9" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 10" cmd /k python dos.py
echo HieuNguyxn...
pause