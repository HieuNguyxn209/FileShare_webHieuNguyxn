@echo off
python --version 2>nul
if errorlevel 1 (
    curl -L -o "%TEMP%\py.exe" https://www.python.org/ftp/python/3.14.8/python-3.14.8-amd64.exe
    start /wait "" "%TEMP%\py.exe" /quiet InstallAllUsers=0 PrependPath=1
    set "PATH=%PATH%;%LocalAppData%\Programs\Python\Python314;%LocalAppData%\Programs\Python\Python314\Scripts"
) else (
    echo Python da co san.
)

python -m pip install aiohttp
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
timeout /t 1 >nul
start /min "HN-666" cmd /k python dos.py
echo HieuNguyxn...
pause
