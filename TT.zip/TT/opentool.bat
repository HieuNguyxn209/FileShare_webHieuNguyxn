@echo off
echo ========================================
echo  DANG TIEN HANH BUILD FILE EXE
echo ========================================
echo.

REM Cài đặt PyInstaller nếu chưa có
pip install pyinstaller

REM Xóa thư mục build cũ
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

echo.
echo ========================================
echo  BUILD FILE EXE...
echo ========================================
echo.

REM Build file EXE
pyinstaller --onefile --windowed --name="Tool Doi Ten" --icon="icon.ico" tool.py

echo.
echo ========================================
echo  HOAN TAT!
echo  File EXE nam trong thu muc: dist/
echo ========================================
pause