import os
import re
import shutil
from pathlib import Path
from tkinter import Tk, filedialog, messagebox, scrolledtext
import tkinter as tk
from tkinter import ttk

class FileRenamer:
    def __init__(self):
        self.source_folder = ""
        self.destination_folder = ""
        self.mapping_list = []  # Danh sách các cặp (tên_cũ, tên_mới)
        self.matches = []
        
    def load_names_from_text(self, text):
        """
        Tải danh sách từ văn bản
        Format: "tên_file_cũ | tên_file_mới"
        """
        lines = [line.strip() for line in text.strip().split('\n') if line.strip()]
        
        self.mapping_list = []
        error_lines = []
        
        for line in lines:
            if '|' in line:
                parts = line.split('|')
                old_name = parts[0].strip()
                new_name = parts[1].strip()
                
                if old_name and new_name:
                    self.mapping_list.append({
                        'old_name': old_name,
                        'new_name': new_name
                    })
                else:
                    error_lines.append(line)
            else:
                error_lines.append(line)
        
        if error_lines:
            print(f"Cảnh báo: {len(error_lines)} dòng không đúng định dạng")
        
        return len(self.mapping_list)
    
    def get_all_files(self):
        """
        Lấy danh sách tất cả file trong thư mục nguồn
        """
        if not self.source_folder or not os.path.exists(self.source_folder):
            raise Exception("Thư mục nguồn không tồn tại!")
        
        files = [f for f in os.listdir(self.source_folder) 
                if os.path.isfile(os.path.join(self.source_folder, f))]
        return files
    
    def find_matches(self):
        """
        Tìm và ghép nối file cũ với tên mới
        """
        files = self.get_all_files()
        
        if not files:
            raise Exception("Không tìm thấy file nào trong thư mục!")
        
        if not self.mapping_list:
            raise Exception("Chưa có danh sách mapping!")
        
        # Tạo dict để tra cứu nhanh
        file_dict = {f.lower(): f for f in files}
        
        self.matches = []
        used_names = set()
        
        for mapping in self.mapping_list:
            old_name = mapping['old_name']
            new_name = mapping['new_name']
            
            # Tìm file khớp với tên cũ (không phân biệt hoa thường)
            old_name_lower = old_name.lower()
            
            if old_name_lower in file_dict:
                actual_file = file_dict[old_name_lower]
                ext = os.path.splitext(actual_file)[1]
                new_filename = new_name + ext
                
                # Xử lý trùng tên
                counter = 1
                temp_new_filename = new_filename
                while temp_new_filename in used_names:
                    name_without_ext = new_name
                    temp_new_filename = f"{name_without_ext}_{counter}{ext}"
                    counter += 1
                
                self.matches.append({
                    'old_name': actual_file,
                    'new_name': temp_new_filename,
                    'old_path': os.path.join(self.source_folder, actual_file),
                    'new_path': os.path.join(
                        self.destination_folder or self.source_folder,
                        temp_new_filename
                    ),
                    'matched': True,
                    'status': 'Đã tìm thấy'
                })
                used_names.add(temp_new_filename)
            else:
                # Tìm file gần đúng (chứa từ khóa)
                found = False
                old_name_keywords = re.sub(r'\.pdf$', '', old_name, flags=re.IGNORECASE)
                old_name_keywords = re.sub(r'\.\w+$', '', old_name_keywords)
                
                for file in files:
                    if file.lower() in used_names:
                        continue
                    
                    # Kiểm tra nếu tên file chứa từ khóa
                    if old_name_keywords.lower() in file.lower():
                        ext = os.path.splitext(file)[1]
                        new_filename = new_name + ext
                        
                        counter = 1
                        temp_new_filename = new_filename
                        while temp_new_filename in used_names:
                            name_without_ext = new_name
                            temp_new_filename = f"{name_without_ext}_{counter}{ext}"
                            counter += 1
                        
                        self.matches.append({
                            'old_name': file,
                            'new_name': temp_new_filename,
                            'old_path': os.path.join(self.source_folder, file),
                            'new_path': os.path.join(
                                self.destination_folder or self.source_folder,
                                temp_new_filename
                            ),
                            'matched': True,
                            'status': 'Tìm thấy (gần đúng)'
                        })
                        used_names.add(temp_new_filename)
                        found = True
                        break
                
                if not found:
                    self.matches.append({
                        'old_name': old_name,
                        'new_name': new_name,
                        'matched': False,
                        'status': '❌ Không tìm thấy file'
                    })
        
        return self.matches
    
    def preview_rename(self):
        """
        Xem trước kết quả đổi tên
        """
        return self.find_matches()
    
    def execute_rename(self):
        """
        Thực hiện đổi tên
        """
        if not self.matches:
            self.find_matches()
        
        if not self.matches:
            return False, "Không tìm thấy file nào phù hợp để đổi tên!"
        
        # Tạo thư mục đích nếu cần
        if self.destination_folder and self.destination_folder != self.source_folder:
            os.makedirs(self.destination_folder, exist_ok=True)
        
        # Thực hiện đổi tên
        success_count = 0
        errors = []
        
        for match in self.matches:
            if not match.get('matched', False):
                continue
                
            try:
                if self.destination_folder and self.destination_folder != self.source_folder:
                    # Copy file sang thư mục đích với tên mới
                    shutil.copy2(match['old_path'], match['new_path'])
                else:
                    # Đổi tên trực tiếp
                    os.rename(match['old_path'], match['new_path'])
                success_count += 1
            except Exception as e:
                errors.append(f"{match['old_name']}: {str(e)}")
        
        result_msg = f"✅ Đã đổi tên thành công {success_count}/{len(self.matches)} file"
        if errors:
            result_msg += f"\n❌ Lỗi: {', '.join(errors[:3])}"
            if len(errors) > 3:
                result_msg += f" và {len(errors)-3} lỗi khác"
        
        return success_count > 0, result_msg

class RenameApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Công Cụ Đổi Tên File - HieuNguyxn_DeepSeak")
        self.root.geometry("1100x850")
        
        self.renamer = FileRenamer()
        self.create_widgets()
        
    def create_widgets(self):
        # Frame chính với scrollbar
        main_container = ttk.Frame(self.root)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        canvas = tk.Canvas(main_container)
        scrollbar = ttk.Scrollbar(main_container, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        main_frame = scrollable_frame
        
        # 1. Chọn thư mục
        frame1 = ttk.LabelFrame(main_frame, text="📁 1. Chọn thư mục chứa file cần đổi tên", padding="10")
        frame1.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(frame1, text="Thư mục nguồn:").grid(row=0, column=0, sticky=tk.W)
        self.source_var = tk.StringVar()
        ttk.Entry(frame1, textvariable=self.source_var, width=80).grid(row=0, column=1, padx=5)
        ttk.Button(frame1, text="Chọn thư mục", command=self.select_source_folder).grid(row=0, column=2)
        
        # 2. Thư mục đích
        frame2 = ttk.LabelFrame(main_frame, text="💾 2. Thư mục lưu file đã đổi tên (tùy chọn)", padding="10")
        frame2.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(frame2, text="Thư mục đích:").grid(row=0, column=0, sticky=tk.W)
        self.dest_var = tk.StringVar()
        self.dest_var.set("(Giữ nguyên thư mục gốc)")
        ttk.Entry(frame2, textvariable=self.dest_var, width=80).grid(row=0, column=1, padx=5)
        ttk.Button(frame2, text="Chọn thư mục", command=self.select_dest_folder).grid(row=0, column=2)
        
        # 3. Danh sách mapping
        frame3 = ttk.LabelFrame(main_frame, text="📝 3. Danh sách mapping (tên cũ | tên mới)", padding="10")
        frame3.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Nút chức năng
        btn_frame = ttk.Frame(frame3)
        btn_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(btn_frame, text="📋 Dán từ Clipboard", command=self.paste_from_clipboard).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="📂 Tải từ file", command=self.load_from_file).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="🗑️ Xóa danh sách", command=self.clear_name_list).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="📊 Thống kê", command=self.show_statistics).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="📥 Tải mẫu", command=self.load_sample_data).pack(side=tk.LEFT, padx=2)
        
        # Text area
        self.name_text = scrolledtext.ScrolledText(frame3, height=15, wrap=tk.NONE)
        self.name_text.pack(fill=tk.BOTH, expand=True)
        
        # Thông tin
        info_frame = ttk.Frame(frame3)
        info_frame.pack(fill=tk.X, pady=(5, 0))
        
        self.count_label = ttk.Label(info_frame, text="Số lượng: 0 mapping")
        self.count_label.pack(side=tk.LEFT)
        
        # Hướng dẫn
        help_frame = ttk.Frame(frame3)
        help_frame.pack(fill=tk.X, pady=(5, 0))
        help_text = "💡 Format: 'tên_file_cũ.pdf | tên_mới' (mỗi dòng 1 cặp mapping)"
        ttk.Label(help_frame, text=help_text, foreground="blue").pack(side=tk.LEFT)
        
        # 4. Nút thực hiện
        btn_frame3 = ttk.Frame(main_frame)
        btn_frame3.pack(pady=10)
        
        ttk.Button(btn_frame3, text="👁️ Xem trước", command=self.preview, width=15).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame3, text="🚀 Thực hiện đổi tên", command=self.execute, width=20).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame3, text="🔄 Làm mới", command=self.clear_results, width=15).pack(side=tk.LEFT, padx=5)
        
        # 5. Kết quả
        frame5 = ttk.LabelFrame(main_frame, text="📊 Kết quả xem trước", padding="10")
        frame5.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.result_text = scrolledtext.ScrolledText(frame5, height=10, wrap=tk.NONE)
        self.result_text.pack(fill=tk.BOTH, expand=True)
        
        # Pack canvas và scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Ràng buộc sự kiện
        self.name_text.bind('<KeyRelease>', self.update_count)
        
        # Tự động load dữ liệu mẫu
        self.load_sample_data()
        
    def load_sample_data(self):
        """Load dữ liệu mẫu"""
        sample_data = """TÊN FILE CŨ.pdf | TÊN FILE MỚI"""
        
        self.name_text.insert('1.0', sample_data)
        self.update_count()
        
    def select_source_folder(self):
        folder = filedialog.askdirectory(title="Chọn thư mục chứa file cần đổi tên")
        if folder:
            self.source_var.set(folder)
            self.renamer.source_folder = folder
            self.show_files_in_folder()
            
    def show_files_in_folder(self):
        """Hiển thị danh sách file trong thư mục"""
        try:
            files = [f for f in os.listdir(self.source_var.get()) 
                    if os.path.isfile(os.path.join(self.source_var.get(), f))]
            
            self.result_text.delete('1.0', tk.END)
            self.result_text.insert('1.0', f"📁 Tìm thấy {len(files)} file trong thư mục:\n")
            self.result_text.insert('1.0', "="*70 + "\n")
            for i, file in enumerate(files[:30], 1):
                self.result_text.insert('1.0', f"{i:3d}. {file}\n")
            if len(files) > 30:
                self.result_text.insert('1.0', f"\n... và {len(files)-30} file khác\n")
        except:
            pass
            
    def select_dest_folder(self):
        folder = filedialog.askdirectory(title="Chọn thư mục lưu file đã đổi tên")
        if folder:
            self.dest_var.set(folder)
            self.renamer.destination_folder = folder
            
    def paste_from_clipboard(self):
        try:
            clipboard_content = self.root.clipboard_get()
            self.name_text.delete('1.0', tk.END)
            self.name_text.insert('1.0', clipboard_content)
            self.update_count()
        except:
            messagebox.showerror("Lỗi", "Không thể lấy dữ liệu từ Clipboard")
            
    def load_from_file(self):
        file_path = filedialog.askopenfilename(
            title="Chọn file chứa danh sách mapping",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    self.name_text.delete('1.0', tk.END)
                    self.name_text.insert('1.0', content)
                    self.update_count()
            except Exception as e:
                messagebox.showerror("Lỗi", f"Không thể đọc file: {str(e)}")
                
    def clear_name_list(self):
        self.name_text.delete('1.0', tk.END)
        self.update_count()
        
    def clear_results(self):
        self.result_text.delete('1.0', tk.END)
        self.renamer.matches = []
        
    def update_count(self, event=None):
        content = self.name_text.get('1.0', tk.END).strip()
        lines = [line.strip() for line in content.split('\n') if line.strip()]
        valid_mappings = sum(1 for line in lines if '|' in line)
        self.count_label.config(text=f"Số lượng: {valid_mappings} mapping")
        
    def show_statistics(self):
        """Hiển thị thống kê về danh sách mapping"""
        content = self.name_text.get('1.0', tk.END).strip()
        lines = [line.strip() for line in content.split('\n') if line.strip()]
        
        if not lines:
            messagebox.showinfo("Thống kê", "Chưa có dữ liệu!")
            return
        
        valid_mappings = [line for line in lines if '|' in line]
        invalid_mappings = [line for line in lines if '|' not in line]
        
        stats = f"📊 Tổng số dòng: {len(lines)}\n"
        stats += f"✅ Số mapping hợp lệ: {len(valid_mappings)}\n"
        stats += f"❌ Số dòng không hợp lệ: {len(invalid_mappings)}\n"
        stats += "="*40 + "\n"
        
        if invalid_mappings:
            stats += "\n⚠️ Các dòng không hợp lệ:\n"
            for line in invalid_mappings[:5]:
                stats += f"  - {line}\n"
            if len(invalid_mappings) > 5:
                stats += f"  ... và {len(invalid_mappings)-5} dòng khác\n"
        
        # Hiển thị 5 mapping đầu
        stats += "\n📝 5 mapping đầu tiên:\n"
        for i, line in enumerate(valid_mappings[:5], 1):
            display = line[:60] + "..." if len(line) > 60 else line
            stats += f"  {i}. {display}\n"
            
        messagebox.showinfo("Thống kê", stats)
        
    def preview(self):
        # Lấy danh sách mapping
        content = self.name_text.get('1.0', tk.END).strip()
        if not content:
            messagebox.showwarning("Cảnh báo", "Vui lòng nhập danh sách mapping!")
            return
            
        if not self.source_var.get():
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn thư mục nguồn!")
            return
            
        # Cập nhật renamer
        self.renamer.source_folder = self.source_var.get()
        if self.dest_var.get() and self.dest_var.get() != "(Giữ nguyên thư mục gốc)":
            self.renamer.destination_folder = self.dest_var.get()
        else:
            self.renamer.destination_folder = self.source_var.get()
            
        count = self.renamer.load_names_from_text(content)
        
        if count == 0:
            messagebox.showwarning("Cảnh báo", "Không tìm thấy mapping hợp lệ!\nFormat: 'tên_cũ | tên_mới'")
            return
        
        try:
            matches = self.renamer.preview_rename()
            
            # Hiển thị kết quả
            self.result_text.delete('1.0', tk.END)
            
            # Thông tin tổng quan
            files = self.renamer.get_all_files()
            self.result_text.insert('1.0', f"📁 Tổng số file trong thư mục: {len(files)}\n")
            self.result_text.insert('1.0', f"📝 Tổng số mapping: {len(self.renamer.mapping_list)}\n")
            
            # Đếm số file tìm thấy
            found_count = sum(1 for m in matches if m.get('matched', False))
            self.result_text.insert('1.0', f"✅ Số file sẽ đổi tên: {found_count}/{len(matches)}\n")
            self.result_text.insert('1.0', "="*80 + "\n\n")
            
            if found_count == 0:
                self.result_text.insert('1.0', "⚠️ Không tìm thấy file nào phù hợp để đổi tên!\n\n")
                self.result_text.insert('1.0', "💡 Kiểm tra:\n")
                self.result_text.insert('1.0', "1. Tên file trong thư mục có khớp với tên file cũ không?\n")
                self.result_text.insert('1.0', "2. Có phân biệt chữ hoa/thường không?\n")
                self.result_text.insert('1.0', "3. Đã chọn đúng thư mục chưa?\n")
                return
                
            # Hiển thị chi tiết
            self.result_text.insert('1.0', "📋 CHI TIẾT ĐỔI TÊN:\n")
            self.result_text.insert('1.0', "-"*80 + "\n")
            
            for i, match in enumerate(matches, 1):
                if match.get('matched', False):
                    status = match.get('status', '✅ Thành công')
                    self.result_text.insert('1.0', f"{i:3d}. {status}\n")
                    self.result_text.insert('1.0', f"     📄 {match['old_name']}\n")
                    self.result_text.insert('1.0', f"     ➜ {match['new_name']}\n")
                else:
                    self.result_text.insert('1.0', f"{i:3d}. ❌ KHÔNG TÌM THẤY\n")
                    self.result_text.insert('1.0', f"     📄 {match['old_name']}\n")
                    self.result_text.insert('1.0', f"     ➜ {match['new_name']}\n")
                self.result_text.insert('1.0', "\n")
                
        except Exception as e:
            messagebox.showerror("Lỗi", str(e))
            
    def execute(self):
        # Kiểm tra đã xem trước chưa
        content = self.result_text.get('1.0', tk.END).strip()
        if not content or "Không tìm thấy" in content or "Số file sẽ đổi tên: 0" in content:
            if not messagebox.askyesno("Xác nhận", "Bạn chưa xem trước hoặc không tìm thấy file phù hợp. Bạn có muốn tiếp tục không?"):
                return
                
        # Xác nhận thực hiện
        if not messagebox.askyesno("Xác nhận", 
            "⚠️ Bạn có chắc chắn muốn đổi tên các file?\n\n"
            "Lưu ý: Hành động này không thể hoàn tác!"):
            return
            
        try:
            success, message = self.renamer.execute_rename()
            if success:
                messagebox.showinfo("Thành công", f"✅ {message}")
                # Cập nhật kết quả
                self.result_text.delete('1.0', tk.END)
                self.result_text.insert('1.0', f"✅ {message}\n\n")
                self.result_text.insert('1.0', "📋 Chi tiết các file đã đổi tên:\n")
                self.result_text.insert('1.0', "="*70 + "\n")
                for match in self.renamer.matches:
                    if match.get('matched', False):
                        self.result_text.insert('1.0', f"✓ {match['old_name']}\n")
                        self.result_text.insert('1.0', f"  ➜ {match['new_name']}\n\n")
            else:
                messagebox.showerror("Thất bại", f"❌ {message}")
        except Exception as e:
            messagebox.showerror("Lỗi", str(e))

def main():
    root = tk.Tk()
    app = RenameApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()